<div>
fffffffffffffffffffffffffffffff

</div><?php /**PATH /home/testi/public_html/artstore/resources/views/test.blade.php ENDPATH**/ ?>