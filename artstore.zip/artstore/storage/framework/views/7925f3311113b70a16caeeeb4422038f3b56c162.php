<?php $__env->startSection('content'); ?>
<div>
<div class="hero-img">
<div class="hero-text">
    <h1>Hello, <span style="color:#ff886e "> <?php echo e($user); ?></span></h1>
    <h5>Here you can see list of your arts</h5>
    
</div>
</div>
</div>

<div class="container">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                      <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div id="home"></div>
  
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/testi/public_html/artstore/resources/views/home.blade.php ENDPATH**/ ?>